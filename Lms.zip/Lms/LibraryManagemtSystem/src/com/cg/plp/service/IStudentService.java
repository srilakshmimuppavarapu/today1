package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.exception.LibraryException;

public interface IStudentService
{
	public ArrayList<BookBean> showBooks() throws LibraryException;

	public int isBookAvailable(String bookId) throws LibraryException;

	public String addRequest(String userId, String bookId) throws LibraryException;

	public ArrayList<BookRegistrationBean> showUserBooks(String userid) throws LibraryException;

	public int returnBook(String transactionId, String bookId)  throws LibraryException;
}
