package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.dao.ILMSDao;
import com.cg.plp.dao.LMSDaoImpl;
import com.cg.plp.exception.LibraryException;

public class LibrarianServiceImpl implements ILibrarianService 
{
	ILMSDao lmsDao=new LMSDaoImpl(); 
	
	public boolean addBooks(BookBean bookBean) throws LibraryException
	{
		return lmsDao.addBooks(bookBean);
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		return lmsDao.removeBook(bookId);
	}

	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException 
	{
		return lmsDao.showBooks();
	}
}
