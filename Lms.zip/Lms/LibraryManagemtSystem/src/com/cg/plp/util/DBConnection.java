package com.cg.plp.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBConnection 
{
	public static Connection getConnection() 
	{
		InitialContext ic;
		Connection connection=null;
		try
		{
			ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			connection=ds.getConnection();
			
		}
		catch(NamingException e)
		{
			System.out.println(e.getMessage());
		}
		catch(SQLException e1)
		{
			System.out.println(e1.getMessage());
		}
		return connection;
	}
}
