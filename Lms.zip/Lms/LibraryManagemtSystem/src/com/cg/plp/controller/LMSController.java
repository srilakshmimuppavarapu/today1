package com.cg.plp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.service.ILibrarianService;
import com.cg.plp.service.IStudentService;
import com.cg.plp.service.IUserService;
import com.cg.plp.service.LibrarianServiceImpl;
import com.cg.plp.service.StudentServiceImpl;
import com.cg.plp.service.UserServiceImpl;


@WebServlet("/LMSController")
public class LMSController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
           
    public LMSController() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		
		int status=0;
		boolean addStatus=false;

		ArrayList<BookBean> booksInventory;
		
		HttpSession session=request.getSession();
		
		IUserService userService=new UserServiceImpl();
		BookBean bookBean=new BookBean();
		ILibrarianService librarianServiceImpl=new LibrarianServiceImpl();
		IStudentService studentServiceImpl=new StudentServiceImpl();
	//	UserBean userBean1=new UserBean();
		
		String operation=request.getParameter("action");
		
		if(operation!=null && operation.equals("register"))
		{
			String userName = request.getParameter("userName");
			String password =  request.getParameter("password");
			String reEnterPassword = request.getParameter("reEnteredPassword");
			String email = request.getParameter("emailId");
			String role=request.getParameter("user");
			if(password.equals(reEnterPassword))
			{
				UserBean userBean = new UserBean();
				userBean.setName(userName);
				userBean.setPassword(password);
				userBean.setEmailId(email);
				userBean.setLibrarian(role);
				
				try
				{
					 String registeredUserId = userService.addDetails(userBean);
					//out.println(userId);
					request.setAttribute("userid",registeredUserId);			
					getServletContext().getRequestDispatcher("/RegistrationStatus.jsp").forward(request,response);
				}
				catch (LibraryException e) 
				{
					out.println(e.getMessage());		
				}
			}
			else
			{
				out.println("<center><font color=aqua>Registration is not Successful please do register again</font></center>");
				getServletContext().getRequestDispatcher("/Registration.jsp").include(request,response);
				
			}	
		}
		
		if(operation!=null && operation.equals("login"))
		{
			try 
			{
				
				String userid=request.getParameter("userId");
				
				
				String password=request.getParameter("password");
					
				status=userService.isUserValid(userid,password);
				
				if(status==0)
				{
					out.println("<center> <font color='red'> Invalid username or password </font> </center>");
					RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
					rd.include(request, response);
				}
				
				else if(status==1)
				{
					session.setAttribute("userid", userid);
					RequestDispatcher rd=request.getRequestDispatcher("/Librarian.jsp");
					rd.forward(request, response);
				}
				
				else if(status==2)
				{
					session.setAttribute("userid", userid);
					
					String userName=null;
					userName=userService.getUserName(userid);

//					System.out.print(userName);
					request.setAttribute("username", userName);
					RequestDispatcher rd=request.getRequestDispatcher("/Student.jsp");
					rd.forward(request, response);
				}
						
			}
			catch (LibraryException e) 
			{
				out.println(e.getMessage());		
			}
		}
		
		if(operation!=null && operation.equals("addBooks"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/AddBooks.jsp");
			rd.forward(request, response);
		}
		
		if(operation!=null && operation.equals("addedBooks"))
		{
			String addedBookId=request.getParameter("bookId");
			String bookName=request.getParameter("bookName");
			String author1=request.getParameter("author1");
			String author2=request.getParameter("author2");
			String publisher=request.getParameter("publisher");
			String yearOfPublication=request.getParameter("yearOfPublication");
			int numberOfCopies=Integer.parseInt(request.getParameter("numberOfCopies"));
			
			bookBean.setBookId(addedBookId);
			bookBean.setBookName(bookName);
			bookBean.setAuthor1(author1);
			bookBean.setAuthor2(author2);
			bookBean.setPublisher(publisher);
			bookBean.setYearOfPublication(yearOfPublication);
			bookBean.setNoOfCopies(numberOfCopies);
			
			try 
			{
				addStatus=librarianServiceImpl.addBooks(bookBean);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}
			
			if(addStatus)
			{
				out.println("Added books successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("Failed to add book");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			
		}
		
		if(operation!=null && operation.equals("removeBooks"))
		{
			try 
			{
				ArrayList<BookBean> booksInventory1=librarianServiceImpl.showBooks();
				request.setAttribute("booksInventory", booksInventory1);
				
				RequestDispatcher rd=request.getRequestDispatcher("/RemoveBooks.jsp"); 
				rd.forward(request, response);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}			
		}
		
		if(operation!=null && operation.equals("removedBooks"))
		{
			boolean removedStatus=false;
			String removedBookId=request.getParameter("bookId");
			try
			{
				removedStatus=librarianServiceImpl.removeBook(removedBookId);
			} 
			catch (LibraryException e)
			{
				out.println(e.getMessage());
			}
			if(removedStatus)
			{
				out.println("Book is removed successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("Failed in removing the book");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
				
		}
		
		if(operation!=null && operation.equals("manageBooks"))
		{
			try 
			{
				ArrayList<BookRegistrationBean> bookRegistrations=librarianServiceImpl.showRegisteredBooks();
				request.setAttribute("bookRegistrations", bookRegistrations);
				
				RequestDispatcher rd=request.getRequestDispatcher("/grantBooks.jsp"); 
				rd.forward(request, response);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}	
		}
		
		if(operation!=null && operation.equals("grant"))
		{
			String transactionId=null;
			
			String registrationId=request.getParameter("registrationId"); 
			String bookId=request.getParameter("bookId"); 
			
			try 
			{
				transactionId=librarianServiceImpl.grantBook(registrationId,bookId);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}
			
			if(transactionId!=null)
			{
				out.println("Your book is issued and your transaction id is "+transactionId);
				RequestDispatcher rd=request.getRequestDispatcher("/TransactionPage.jsp"); 
				rd.include(request, response);
			}
			else
			{
				out.println("Requested book is out of copies");
				RequestDispatcher rd=request.getRequestDispatcher("/TransactionPage.jsp"); 
				rd.include(request, response);
			}
		}
		
		
		
		if(operation!=null && operation.equals("request"))
		{
			//ArrayList<BookBean> booksInventory;
			try
			{
				booksInventory = studentServiceImpl.showBooks();
				request.setAttribute("booksInventory", booksInventory);
				
				RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
				rd.forward(request, response);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}			
		}
		
		if(operation!=null && operation.equals("requestedBook"))
		{
			String requestedBookId=request.getParameter("bookId");
			request.setAttribute("requestedBookId", requestedBookId);
			int bookStatus;
			try 
			{
				bookStatus = studentServiceImpl.isBookAvailable(requestedBookId);
				if(bookStatus==1)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/BookAvailable.jsp"); 
					rd.include(request, response);
					
					
				}
				else if(bookStatus==2)
				{
					out.println("Requested book is out of copies");
					RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
					rd.include(request, response);
				}
				else if(bookStatus==3)
				{
					out.println("Entered bookid doesnot match with any of the books");
					RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
					rd.include(request, response);
				}				
			} 
			catch (LibraryException e)
			{
				out.println(e.getMessage());
			}			
		}
		
		if(operation!=null && operation.equals("placeRequest"))
		{
				String registrationId;
				String requestedBookId=request.getParameter("requestedBookId");
				try 
				{
					
					String userId=(String) session.getAttribute("userid");
							
					System.out.println("userId : "+userId);
					System.out.println("bookId : "+requestedBookId);
					
					registrationId = studentServiceImpl.addRequest(userId,requestedBookId);
					if(registrationId==null)
					{
						out.println("Request for the book cannot be placed more than 1 time");
						RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
						rd.include(request, response);
						
					}
					else
					{
						out.println("Request placed and your registration id is "+registrationId);
						RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
						rd.include(request, response);
					}
				} 
				catch (LibraryException e) 
				{
					out.println(e.getMessage());
				}
				
		}
		
		if(operation!=null && operation.equals("return"))
		{
			int fine=0;
			String userid=(String) session.getAttribute("userid");
			try 
			{
				ArrayList<BookRegistrationBean> userBooks=studentServiceImpl.showUserBooks(userid);
				request.setAttribute("userBooks", userBooks);
				
				RequestDispatcher rd=request.getRequestDispatcher("/ReturnBook.jsp"); 
				rd.include(request, response);
				
				String transactionId=request.getParameter("transactionId");
				String bookId=request.getParameter("bookId");

				fine = studentServiceImpl.returnBook(transactionId,bookId);
				
				out.println("Your book is returned successfully and your fine is "+fine);
			} 
			catch (LibraryException e)
			{
				out.println(e.getMessage());
			}
		}
	}

}
