package com.cg.plp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.plp.bean.BookBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.service.ILibrarianService;
import com.cg.plp.service.IUserService;
import com.cg.plp.service.LibrarianServiceImpl;
import com.cg.plp.service.UserServiceImpl;


@WebServlet("/LMSController")
public class LMSController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
           
    public LMSController() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		
		int status=0;
		boolean addStatus=false;
		
		IUserService userService=new UserServiceImpl();
		BookBean bookBean=new BookBean();
		ILibrarianService librarianServiceImpl=new LibrarianServiceImpl();
		
		String operation=request.getParameter("action");
		
		if(operation!=null && operation.equals("login"))
		{
			try 
			{
				
				String userId=request.getParameter("userId");
				String password=request.getParameter("password");
					
				status=userService.isUserValid(userId,password);
				
				if(status==0)
				{
					out.println("<center> <font color='red'> Invalid username or password </font> </center>");
					RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
					rd.include(request, response);
				}
				
				else if(status==1)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/Librarian.jsp");
					rd.forward(request, response);
				}
				
				else if(status==2)
				{
					
				}
						
			}
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
				
			}
		}
		
		if(operation!=null && operation.equals("addBooks"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/AddBooks.jsp");
			rd.forward(request, response);
		}
		
		if(operation!=null && operation.equals("addedBooks"))
		{
			String bookId=request.getParameter("bookId");
			String bookName=request.getParameter("bookName");
			String author1=request.getParameter("author1");
			String author2=request.getParameter("author2");
			String publisher=request.getParameter("publisher");
			String yearOfPublication=request.getParameter("yearOfPublication");
			int numberOfCopies=Integer.parseInt(request.getParameter("numberOfCopies"));
			
			bookBean.setBookId(bookId);
			bookBean.setBookName(bookName);
			bookBean.setAuthor1(author1);
			bookBean.setAuthor2(author2);
			bookBean.setPublisher(publisher);
			bookBean.setYearOfPublication(yearOfPublication);
			bookBean.setNoOfCopies(numberOfCopies);
			
			try 
			{
				addStatus=librarianServiceImpl.addBooks(bookBean);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}
			
			if(addStatus)
			{
				out.println("Added books successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("Failed to add book");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			
		}
		
		if(operation!=null && operation.equals("removeBooks"))
		{
			try 
			{
				ArrayList<BookBean> booksInventory=librarianServiceImpl.showBooks();
				request.setAttribute("booksInventory", booksInventory);
				
				RequestDispatcher rd=request.getRequestDispatcher("/RemoveBooks.jsp"); 
				rd.forward(request, response);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}			
		}
		
		if(operation!=null && operation.equals("removedBooks"))
		{
			boolean removedStatus=false;
			String bookId=request.getParameter("bookId");
			try
			{
				removedStatus=librarianServiceImpl.removeBook(bookId);
			} 
			catch (LibraryException e)
			{
				out.println(e.getMessage());
			}
			if(removedStatus)
			{
				out.println("Book is removed successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("Failed in removing the book");
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
				rd.include(request, response);
			}
				
		}
		
		if(operation!=null && operation.equals("manageBooks"))
		{
			try 
			{
				ArrayList<BookBean> booksRegistration=librarianServiceImpl.showRegisteredBooks();
				request.setAttribute("booksRegistration", booksRegistration);
				
				RequestDispatcher rd=request.getRequestDispatcher("/grantBooks.jsp"); 
				rd.forward(request, response);
			} 
			catch (LibraryException e) 
			{
				out.println(e.getMessage());
			}	
		}
	}

}
