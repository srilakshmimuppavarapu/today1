package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;
import com.cg.plp.util.DBConnection;

public class LMSDaoImpl implements ILMSDao
{
	/*******************************************************************************************************
	 - Function Name	:	addDetails()
	 - Input Parameters	:	userBean
	 - Return Type		:	String
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To Register the user
	 ********************************************************************************************************/ 
	@Override
	public String addDetails(UserBean userBean) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String userId=null;
			try
			{
				preparedStatement = connection.prepareStatement("Select user_id_seq.nextval from dual");
				resultSet=preparedStatement.executeQuery();
				resultSet.next();
				userId=resultSet.getString(1);
				preparedStatement.close();

				preparedStatement=connection.prepareStatement("INSERT INTO Users values(?,?,?,?,?)");
				preparedStatement.setString(1,userId);
				preparedStatement.setString(2,userBean.getName());
				preparedStatement.setString(3,userBean.getPassword());
				preparedStatement.setString(4,userBean.getEmailId());
				preparedStatement.setString(5,userBean.getLibrarian());
				preparedStatement.executeUpdate();
				//connection.commit();
				preparedStatement.close();
			}
			catch(SQLException sqlException)
			{
				throw new LibraryException("Caught "+sqlException.getMessage());
			}

			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
					resultSet.close();
				}
				catch (SQLException sqlException) 
				{
					throw new LibraryException("Error in closing database connection in registration page");
				}
			}
		return userId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	isUserValid()
	 - Input Parameters	:	userId, password
	 - Return Type		:	int
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To validate the user
	 ********************************************************************************************************/ 
	
	@Override
	public int isUserValid(String userId, String password) throws LibraryException
	{			
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		int status=0;
		try
		{
			preparedStatement = connection.prepareStatement("SELECT password FROM Users WHERE user_id=?");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(password))
				{
					preparedStatement=connection.prepareStatement("select librarian from Users where user_id=?");
					preparedStatement.setString(1,userId);
					resultSet=preparedStatement.executeQuery();
					resultSet.next();
					String lib=resultSet.getString(1);
					preparedStatement.close();
					if(lib.equals("true"))
						status=1;
					else
						status=2;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=0;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=0;
			}
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration page");
			}
		}
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getUserName()
	 - Input Parameters	:	userId
	 - Return Type		:	String
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To get the user name for the user id
	 ********************************************************************************************************/ 
	
	@Override
	public String getUserName(String userId) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String userName=null;
		try
		{
			preparedStatement = connection.prepareStatement("Select user_name from Users WHERE user_id=?");
			preparedStatement.setString(1,userId);
			
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			userName=resultSet.getString(1);
			//System.out.println("1111"+userName);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration page");
			}
		}
		return userName;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addBooks()
	 - Input Parameters	:	bookBean
	 - Return Type		:	boolean
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To add the new books to the inventory
	 ********************************************************************************************************/ 
	
	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		
		boolean status=false;
		
		try
		{
			preparedStatement = connection.prepareStatement("INSERT INTO BooksInventory VALUES (?,?,?,?,?,?,?)");
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,bookBean.getBookName());
			preparedStatement.setString(3,bookBean.getAuthor1());
			preparedStatement.setString(4,bookBean.getAuthor2());
			preparedStatement.setString(5,bookBean.getPublisher());
			preparedStatement.setString(6,bookBean.getYearOfPublication());
			preparedStatement.setInt(7,bookBean.getNoOfCopies());
			preparedStatement.executeUpdate();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Given Book id already exists in database");
		}
		
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	showBooks()
	 - Return Type		:	ArrayList<BookBean>
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To display the books in the inventory
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;

		ArrayList<BookBean> booksInventory=new ArrayList<BookBean>();
		try
		{
			preparedStatement = connection.prepareStatement("select * from BooksInventory order by book_id");			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookBean bookBean=new BookBean();
				
				bookBean.setBookId(resultSet.getString("book_id"));
				bookBean.setBookName(resultSet.getString("book_name"));
				bookBean.setAuthor1(resultSet.getString("author1"));
				bookBean.setAuthor2(resultSet.getString("author2"));
				bookBean.setPublisher(resultSet.getString("publisher"));
				bookBean.setYearOfPublication(resultSet.getString("yearofpublication"));
				bookBean.setNoOfCopies(resultSet.getInt("no_of_copies"));
				
				booksInventory.add(bookBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return booksInventory;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	removeBook()
	 - Return Type		:	bookId
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To remove the book from the inventory
	 ********************************************************************************************************/
	
	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;		
		boolean status=false;
		
		try
		{
			preparedStatement = connection.prepareStatement("DELETE FROM BooksInventory WHERE book_id=?");
			preparedStatement.setString(1,bookId);
			
			int count=preparedStatement.executeUpdate();
			
			if(count==0)
			{
				throw new LibraryException("Given bookId is not there in the Inventory");
			}
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}		
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	showRegisteredBooks()
	 - Return Type		:	ArrayList<BookRegistrationBean>
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To show the user registered books
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		ArrayList<BookRegistrationBean> bookRegistrations=new ArrayList<BookRegistrationBean>();
		try
		{
			preparedStatement = connection.prepareStatement("select * from booksregistration where status=?");	
			
			preparedStatement.setString(1,"requested");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookRegistrationBean bookRegistrationBean=new BookRegistrationBean();
				
				bookRegistrationBean.setRegistrationId(resultSet.getString("registration_id"));
				bookRegistrationBean.setBookId(resultSet.getString("book_id"));
				bookRegistrationBean.setUserId(resultSet.getString("user_id"));
				bookRegistrationBean.setRegistrationDate(resultSet.getDate("registrationdate"));
				
				bookRegistrations.add(bookRegistrationBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return bookRegistrations;
	}

	@Override
	public String grantBook(String registrationId, String bookId) throws LibraryException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String transactionId=null;		
		String tRegistrationId=null;
		String tBookId=null;
		String tUserId=null;
		Date tRegistrationDate=null;
		
		int copies=0;
		
		try
		{
			preparedStatement=connection.prepareStatement("select no_of_copies from BooksInventory where book_id=?");
			preparedStatement.setString(1,bookId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
				copies=resultSet.getInt(1);
			
			preparedStatement.close();
			
			if(copies>=1)
			{
					preparedStatement = connection.prepareStatement("insert into BooksTransaction(transaction_id,registration_id,issue_date) values (transaction_seq.nextval,?,sysdate)");
					preparedStatement.setString(1,registrationId);
					preparedStatement.executeUpdate();
					preparedStatement.close();
		
					preparedStatement=connection.prepareStatement("select transaction_seq.currval from dual");
					resultSet=preparedStatement.executeQuery();
					while(resultSet.next())
						transactionId=resultSet.getString(1);
					
					/*preparedStatement=connection.prepareStatement("SELECT * FROM BooksRegistration WHERE registration_id=?");
					preparedStatement.setString(1,registrationId);
					resultSet=preparedStatement.executeQuery();
					while(resultSet.next())
					{
						tRegistrationId=resultSet.getString("registration_id");
						tBookId=resultSet.getString("book_id");
						tUserId=resultSet.getString("user_id");
						tRegistrationDate=resultSet.getDate("registrationdate");
					}*/
					
					preparedStatement=connection.prepareStatement("update BooksRegistration set status=? where registration_id=?");
					preparedStatement.setString(1, "issued");
					preparedStatement.setString(2, registrationId);
					preparedStatement.executeUpdate();
					
					preparedStatement=connection.prepareStatement("update BooksInventory set no_of_copies=no_of_copies-1 where book_id=?");
					preparedStatement.setString(1, bookId);
					preparedStatement.executeUpdate();					
			}
			else
			{
				throw new LibraryException("Requested book is out of copies");
			}
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		
		return transactionId;
	}
	
	@Override
	public int isBookAvailable(String bookId) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		int status=0;
		try
		{
			//System.out.println("Entered book id is : "+bookId);
			preparedStatement = connection.prepareStatement("SELECT no_of_copies FROM BooksInventory WHERE book_id=?");
			preparedStatement.setString(1,bookId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int copies=resultSet.getInt("no_of_copies");
				if(copies>0)
				{
					status=1;
				}
				else
				{
					status=2;
				}
			}
			else
				status=3;
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing db connection");
			}
		}
		return status;
	}
	
	@Override
	public String addRequest(String userId, String bookId) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String registrationId=null;
		String bookIdTemp=null;
		String status=null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT book_id FROM BooksRegistration WHERE user_id=?");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				bookIdTemp=resultSet.getString(1);
				if(bookId.equals(bookIdTemp))
				{
					preparedStatement = connection.prepareStatement("SELECT status FROM BooksRegistration WHERE user_id=?");
					preparedStatement.setString(1,userId);
					resultSet=preparedStatement.executeQuery();
					resultSet.next();
					status=resultSet.getString(1);
					System.out.println(status);
					if(status.equals("issued"))
					{
						throw new StudentException("Book is already granted");
					}
					else if(status.equals("requested"))
					{
						throw new StudentException("Request for the book cannot be placed more than 1 time");
					}					
				}			
			}
			preparedStatement.close();
			
			preparedStatement = connection.prepareStatement("INSERT INTO BooksRegistration (registration_id,book_id,user_id,registrationdate,status) VALUES(registration_seq.NEXTVAL,?,?,SYSDATE,?)");
			preparedStatement.setString(1,bookId);
			preparedStatement.setString(2,userId);
			preparedStatement.setString(3, "requested");
			preparedStatement.executeUpdate();
			preparedStatement.close();
			
			preparedStatement=connection.prepareStatement("SELECT registration_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			registrationId=rs.getString(1);
			preparedStatement.close();

		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing db connection");
			}
		}
		return registrationId;
	}
	
	@Override
	public ArrayList<BookRegistrationBean> showUserBooks(String userid) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		ArrayList<BookRegistrationBean> bookRegistrations=new ArrayList<BookRegistrationBean>();
		try
		{
			preparedStatement = connection.prepareStatement("select registration_id,book_id,registrationdate from BooksRegistration WHERE user_id=? and status=? order by registration_id");
			
			preparedStatement.setString(1, userid);
			preparedStatement.setString(2,"issued");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookRegistrationBean bookRegistrationBean=new BookRegistrationBean();
				
				bookRegistrationBean.setRegistrationId(resultSet.getString("registration_id"));
				bookRegistrationBean.setBookId(resultSet.getString("book_id"));
				bookRegistrationBean.setRegistrationDate(resultSet.getDate("registrationdate"));
				
				bookRegistrations.add(bookRegistrationBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing database connection in adding books");
			}
		}
		return bookRegistrations;
	}
	
	@Override
	public int returnBook(String registrationId, String bookId) throws StudentException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String transactionIdTemp=null;
		
		int fine=0;
		try
		{
			preparedStatement=connection.prepareStatement("select Book_id from booksregistration where registration_id=?");
			preparedStatement.setString(1, registrationId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())	
			{
				transactionIdTemp=resultSet.getString(1);
			}
			if(!transactionIdTemp.equals(bookId))
			{
				throw new StudentException("You entered incorrect registration id or book id");
			}
			preparedStatement=connection.prepareStatement("select fine from bookstransaction where registration_id=?");
			preparedStatement.setString(1, registrationId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())	
			{
				fine=resultSet.getInt(1);
			}
			preparedStatement.close();
			
			if(fine!=-1)
			{
				throw new StudentException("the book is already returned");
			}
			else
			{
				fine=0;
				preparedStatement=connection.prepareStatement("UPDATE BooksTransaction SET return_date=SYSDATE WHERE registration_id=?");
				preparedStatement.setString(1, registrationId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement("UPDATE BooksInventory SET no_of_copies=no_of_copies+1 where book_id=?");
				preparedStatement.setString(1, bookId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement("UPDATE BooksRegistration SET status=? WHERE registration_id=?");
				preparedStatement.setString(1, "returned");
				preparedStatement.setString(2, registrationId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement("SELECT issue_date,return_date FROM BooksTransaction WHERE registration_id=?");
				preparedStatement.setString(1, registrationId);
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
				{
					Date issueDate=resultSet.getDate(1);
					Date returnDate=resultSet.getDate(2);
					int days=(int) ((issueDate.getTime()-returnDate.getTime())/(1000*60*60*24));
					
					if(days>30)
						fine=(days-30)*2;
				}
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement("UPDATE BooksTransaction SET fine=? WHERE registration_id=?");
				preparedStatement.setInt(1, fine);
				preparedStatement.setString(2,registrationId);
				preparedStatement.executeUpdate();
			}
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing database connection in registration phase");
			}
		}
		return fine;
	}

}
