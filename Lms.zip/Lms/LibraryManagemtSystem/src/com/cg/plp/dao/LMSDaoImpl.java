package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;

import com.cg.plp.bean.BookBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.util.DBConnection;

public class LMSDaoImpl implements ILMSDao
{
	Connection connection=DBConnection.getConnection();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	
	
	@Override
	public int isUserValid(String userId, String password) throws LibraryException
	{			
		int status=0;
		try
		{
			preparedStatement = connection.prepareStatement("SELECT password FROM Users WHERE user_id=?");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(password))
				{
					preparedStatement=connection.prepareStatement("select librarian from Users where user_id=?");
					preparedStatement.setString(1,userId);
					resultSet=preparedStatement.executeQuery();
					resultSet.next();
					String lib=resultSet.getString(1);
					if(lib.equals("true"))
						status=1;
					else
						status=2;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=0;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=0;
			}
			preparedStatement.close();
			resultSet.close();
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		return status;
	}

	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException 
	{
		boolean status=false;
		
		try
		{
			preparedStatement = connection.prepareStatement("INSERT INTO BooksInventory VALUES (?,?,?,?,?,?,?)");
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,bookBean.getBookName());
			preparedStatement.setString(3,bookBean.getAuthor1());
			preparedStatement.setString(4,bookBean.getAuthor2());
			preparedStatement.setString(5,bookBean.getPublisher());
			preparedStatement.setString(6,bookBean.getYearOfPublication());
			preparedStatement.setInt(7,bookBean.getNoOfCopies());
			preparedStatement.executeUpdate();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return status;
	}

	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException
	{

		ArrayList<BookBean> booksInventory=new ArrayList<BookBean>();
		try
		{
			preparedStatement = connection.prepareStatement("select * from BooksInventory order by book_id");			
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookBean bookBean=new BookBean();
				
				bookBean.setBookId(resultSet.getString("book_id"));
				bookBean.setBookName(resultSet.getString("book_name"));
				bookBean.setAuthor1(resultSet.getString("author1"));
				bookBean.setAuthor2(resultSet.getString("author2"));
				bookBean.setPublisher(resultSet.getString("publisher"));
				bookBean.setYearOfPublication(resultSet.getString("yearofpublication"));
				bookBean.setNoOfCopies(resultSet.getInt("no_of_copies"));
				
				booksInventory.add(bookBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return booksInventory;
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{

		boolean status=false;
		
		try
		{
			preparedStatement = connection.prepareStatement("DELETE FROM BooksInventory WHERE book_id=?");
			preparedStatement.setString(1,bookId);
			
			preparedStatement.executeUpdate();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}		
		return status;
	}

	
}
