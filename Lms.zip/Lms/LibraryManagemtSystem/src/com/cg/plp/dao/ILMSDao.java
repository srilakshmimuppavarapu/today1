package com.cg.plp.dao;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.exception.LibraryException;

public interface ILMSDao
{

	int isUserValid(String userId, String password) throws LibraryException;
	boolean addBooks(BookBean bookBean) throws LibraryException;
	boolean removeBook(String bookId) throws LibraryException;
	ArrayList<BookBean> showBooks()  throws LibraryException;

}
