package com.cg.plp.dao;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;

public interface ILMSDao
{

	int isUserValid(String userId, String password) throws LibraryException;
	boolean addBooks(BookBean bookBean) throws LibraryException;
	boolean removeBook(int numCopy,String bookId) throws LibraryException;

	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException;
	String grantBook(String registrationId, String bookId) throws LibraryException;
	String addDetails(UserBean userBean) throws LibraryException;
	String getUserName(String userId) throws LibraryException;
	
	ArrayList<BookBean> showBooks()  throws LibraryException;
	
	int isBookAvailable(String bookId) throws StudentException;
	String addRequest(String userId, String bookId) throws StudentException;
	ArrayList<BookRegistrationBean> showUserBooks(String userid) throws StudentException;
	int returnBook(String transactionId, String bookId) throws StudentException;
}
