package com.cg.plp.dao;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;

public interface ILMSDao
{

	int isUserValid(String userId, String password) throws LibraryException;
	boolean addBooks(BookBean bookBean) throws LibraryException;
	boolean removeBook(String bookId) throws LibraryException;
	ArrayList<BookBean> showBooks()  throws LibraryException;
	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException;
	String grantBook(String registrationId, String bookId) throws LibraryException;
	String addDetails(UserBean userBean) throws LibraryException;
	String getUserName(String userId) throws LibraryException;
	int isBookAvailable(String bookId) throws LibraryException;
	String addRequest(String userId, String bookId) throws LibraryException;
	ArrayList<BookRegistrationBean> showUserBooks(String userid) throws LibraryException;
	int returnBook(String transactionId, String bookId) throws LibraryException;
}
