package com.cg.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;
import com.cg.ebill.service.EBillServiceImpl;
import com.cg.ebill.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//PrintWriter pw=response.getWriter();
		IEBillService ebill=new EBillServiceImpl();
		String operation=request.getParameter("action");
		
		if(operation.equals("list"))
		{
			ArrayList array=new ArrayList<ConsumerBean>();
			array=ebill.getDetails();
			
			request.setAttribute("arrayobj", array);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_ConsumerList.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("search"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/Search_Consumer.jsp");
			rd.include(request, response);
		}
		
		if(operation.equals("searchuser"))
		{
			//pw.println("hai");
			int consumerno=Integer.parseInt((String) request.getParameter("consumerno"));
			ConsumerBean b=ebill.searchUser(consumerno);
			
			request.setAttribute("bean", b);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_Consumer.jsp");
			rd.forward(request, response);
		}
		
		if(operation.equals("billdetails"))
		{
			//pw.println("hai"); 
			int consumerno=Integer.parseInt(request.getParameter("num"));
			//pw.println(consumerno);
			ArrayList<BillDetailsBean> array=new ArrayList<BillDetailsBean>();
			array=ebill.generateBillDetails(consumerno);
			
			request.setAttribute("arrayobj", array);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_Bills.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("generate"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/User_Info.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("generatedetails"))
		{
			BillDetailsBean bean=new BillDetailsBean();
			
			int consumerno=Integer.parseInt(request.getParameter("conno"));
			int lastmonth=Integer.parseInt(request.getParameter("lmr"));
			int currentmonth=Integer.parseInt(request.getParameter("cmr"));
			int fixedCharge=100;
			
			int unitsConsumed=currentmonth - lastmonth;
			float bill=(unitsConsumed*1.15f)+fixedCharge;
			
			String name=ebill.getName(consumerno);
			
			bean.setName(name);
			bean.setUnitsConsumed(unitsConsumed);
			bean.setBill(bill);
			bean.setConsumerno(consumerno);
			bean.setCurrentreading(currentmonth);
			
			ebill.insertBillDetails(bean);
			
			request.setAttribute("bean", bean);
			RequestDispatcher rd=request.getRequestDispatcher("/Bill_Info.jsp");
			rd.forward(request, response);
			
		}
		if(operation.equals("showbill"))
		{
			int consumerno=Integer.parseInt(request.getParameter("num"));
			ArrayList<BillDetailsBean> array=new ArrayList<BillDetailsBean>();
			array=ebill.generateBillDetails(consumerno);
			
			request.setAttribute("arrayobj", array);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_Bills.jsp");
			rd.forward(request, response);
		}
	}

}
