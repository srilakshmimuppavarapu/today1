package com.cg.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;
import com.cg.ebill.service.EBillServiceImpl;
import com.cg.ebill.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter pw=response.getWriter();
		IEBillService ebill=new EBillServiceImpl();
		String operation=request.getParameter("action");
		
		if(operation.equals("list"))
		{
			ArrayList array=new ArrayList<ConsumerBean>();
			array=ebill.getDetails();
			
			request.setAttribute("arrayobj", array);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_ConsumerList.jsp");
			rd.forward(request, response);
		}
		if(operation.equals("search"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("/Search_Consumer.jsp");
			rd.include(request, response);
		}
		
		if(operation.equals("searchuser"))
		{
			//pw.println("hai");
			int consumerno=Integer.parseInt((String) request.getParameter("consumerno"));
			ConsumerBean b=ebill.searchUser(consumerno);
			
			request.setAttribute("bean", b);
			RequestDispatcher rd=request.getRequestDispatcher("/Show_Consumer.jsp");
			rd.forward(request, response);
		}
		
		if(operation.equals("billdetails"))
		{
			int consumerno=(int) request.getAttribute("consumerno");
			BillDetailsBean bean=ebill.generateBillDetails(consumerno);
			
			
		}
	}

}
