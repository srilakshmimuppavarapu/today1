package com.cg.ebill.bean;

public class BillDetailsBean 
{
	private int consumerno;
	private int billno;
	private int currentreading;
	private int unitsConsumed;
	private float bill;
	private String billdate;
	
	public int getConsumerno() 
	{
		return consumerno;
	}
	public void setConsumerno(int consumerno)
	{
		this.consumerno = consumerno;
	}
	
	public int getBillno()
	{
		return billno;
	}
	public void setBillno(int billno) 
	{
		this.billno = billno;
	}
	
	public int getCurrentreading()
	{
		return currentreading;
	}
	public void setCurrentreading(int currentreading) 
	{
		this.currentreading = currentreading;
	}
	
	public int getUnitsConsumed() 
	{
		return unitsConsumed;
	}
	public void setUnitsConsumed(int unitsConsumed)
	{
		this.unitsConsumed = unitsConsumed;
	}
	
	public float getBill() 
	{
		return bill;
	}
	public void setBill(float bill) 
	{
		this.bill = bill;
	}
	
	public String getBilldate() 
	{
		return billdate;
	}
	public void setBilldate(String billdate)
	{
		this.billdate = billdate;
	}
	
	
}
