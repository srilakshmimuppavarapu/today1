package com.cg.ebill.service;

import java.util.ArrayList;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;

public interface IEBillService 
{

	ArrayList getDetails();

	ConsumerBean searchUser(int consumerno);

	ArrayList generateBillDetails(int consumerno);

	String getName(int consumerno);

	void insertBillDetails(BillDetailsBean bean);

}
