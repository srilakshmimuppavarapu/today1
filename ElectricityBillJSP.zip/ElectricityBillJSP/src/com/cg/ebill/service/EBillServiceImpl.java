package com.cg.ebill.service;

import java.util.ArrayList;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;
import com.cg.ebill.dao.EBillDaoImpl;
import com.cg.ebill.dao.IEBillDao;

public class EBillServiceImpl implements IEBillService
{
	IEBillDao ebill=new EBillDaoImpl();
	
	@Override
	public ArrayList getDetails() 
	{
		return ebill.getDetails();
	}

	@Override
	public ConsumerBean searchUser(int consumerno)
	{
		return ebill.searchUser(consumerno);
	}

	@Override
	public ArrayList generateBillDetails(int consumerno)
	{
		return ebill.generateBillDetails(consumerno);
	}

	@Override
	public String getName(int consumerno)
	{
		return ebill.getName(consumerno);
	}

	@Override
	public void insertBillDetails(BillDetailsBean bean) 
	{
		ebill.insertBillDetails(bean);
	}

}
