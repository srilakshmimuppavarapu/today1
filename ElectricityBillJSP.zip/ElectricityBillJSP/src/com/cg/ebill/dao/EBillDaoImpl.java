package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;

public class EBillDaoImpl implements IEBillDao
{

	@Override
	public ArrayList getDetails() 
	{
		ArrayList array=new ArrayList<ConsumerBean>();
		
		InitialContext ic;
		try
		{
			ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			Statement statement=con.createStatement();
			ResultSet rs=statement.executeQuery("Select * from consumers");
			
			while(rs.next())
			{
				ConsumerBean bean=new ConsumerBean();
				bean.setUserId(rs.getInt("consumer_num"));
				bean.setUserName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));
				
				array.add(bean);	
			}
		} 
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		
		return array;
	}

	@Override
	public ConsumerBean searchUser(int consumerno) 
	{
		ConsumerBean bean=new ConsumerBean();
		
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			PreparedStatement statement=con.prepareStatement("select * from consumers where consumer_num=?");
			statement.setInt(1, consumerno);
			ResultSet rs=statement.executeQuery();
			
			while(rs.next())
			{
				bean.setUserId(rs.getInt("consumer_num"));
				bean.setUserName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));			
			}
			
		}
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		return bean;
	}

	@Override
	public ArrayList generateBillDetails(int consumerno) 
	{
		ArrayList<BillDetailsBean> b=new ArrayList<BillDetailsBean>();
		
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement("select * from billdetails where consumer_num= ?");
			ps.setInt(1, consumerno);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				BillDetailsBean bean=new BillDetailsBean();
				
				bean.setBillno(rs.getInt(1));
				bean.setConsumerno(rs.getInt(2));
				bean.setCurrentreading(rs.getInt(3));
				bean.setUnitsConsumed(rs.getInt(4));
				bean.setBill(rs.getFloat(5));
				bean.setBilldate(rs.getString(6));
				
				b.add(bean);
			}
		}
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		return b;
	}

	@Override
	public String getName(int consumerno) 
	{
		String name=null;
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement("select consumer_name from consumers where consumer_num= ?");
			ps.setInt(1, consumerno);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				name=rs.getNString(1);
			}
		}
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		return name;
	}

	@Override
	public void insertBillDetails(BillDetailsBean bean)
	{
		Connection con=null;
		try
		{
		
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			//System.out.println("hai");
			con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement("insert into billdetails values(seq_bill_num.nextval,?,?,?,?,SYSDATE)");
			ps.setInt(1,bean.getConsumerno());
			ps.setInt(2, bean.getCurrentreading());
			ps.setInt(3, bean.getUnitsConsumed());
			ps.setFloat(4, bean.getBill());
			//System.out.println("haiiiii");
			ps.executeUpdate();
			con.commit();
			con.close();
		}
		
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		
		
		
	}

}
