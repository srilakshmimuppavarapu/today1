package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.ebill.bean.BillDetailsBean;
import com.cg.ebill.bean.ConsumerBean;

public class EBillDaoImpl implements IEBillDao
{

	@Override
	public ArrayList getDetails() 
	{
		ArrayList array=new ArrayList<ConsumerBean>();
		
		InitialContext ic;
		try
		{
			ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			Statement statement=con.createStatement();
			ResultSet rs=statement.executeQuery("Select * from consumers");
			
			while(rs.next())
			{
				ConsumerBean bean=new ConsumerBean();
				bean.setUserId(rs.getInt("consumer_num"));
				bean.setUserName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));
				
				array.add(bean);	
			}
		} 
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		
		return array;
	}

	@Override
	public ConsumerBean searchUser(int consumerno) 
	{
		ConsumerBean bean=new ConsumerBean();
		
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			PreparedStatement statement=con.prepareStatement("select * from consumers where consumer_num=?");
			statement.setInt(1, consumerno);
			ResultSet rs=statement.executeQuery();
			
			while(rs.next())
			{
				bean.setUserId(rs.getInt("consumer_num"));
				bean.setUserName(rs.getString("consumer_name"));
				bean.setAddress(rs.getString("address"));			
			}
			
		}
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		return bean;
	}

	@Override
	public BillDetailsBean generateBillDetails(int consumerno) 
	{
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			
			Connection con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement("select * from billdetails where )
		}
		catch (NamingException | SQLException e)
		{
			e.getMessage();
		}
		return null;
	}

}
