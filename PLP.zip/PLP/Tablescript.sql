CREATE SEQUENCE registration_seq 
INCREMENT BY 1 
START WITH 1;

CREATE SEQUENCE transaction_seq 
INCREMENT BY 1 
START WITH 101;

CREATE SEQUENCE user_id_seq
INCREMENT BY 1
START WITH 1001;

CREATE TABLE UserTable(
userid VARCHAR2(4),
password VARCHAR2(7),
name VARCHAR2(20),
emailid VARCHAR2(25),
address VARCHAR2(50),
gender VARCHAR2(7),
phnnumber VARCHAR2(10),
librarian CHAR(1));

INSERT INTO UserTable VALUES('1001','abc123','Harika','ht@capgemini.com','capgemini office1','Female','9798765431','N');
INSERT INTO UserTable VALUES('1002','abc124','Pooj','pj@capgemini.com','capgemini office2','Female','9712365432','N');
INSERT INTO UserTable VALUES('1003','staff1','Divya','dc@capgemini.com','capgemini office1','Female','9267665436','Y');
INSERT INTO UserTable VALUES('1004','staff2','Ketya','nk@capgemini.com','capgemini office2','Male','9778535743','Y');


CREATE TABLE BooksInventory(
book_id VARCHAR2(4),
book_name VARCHAR2(30),
author1 VARCHAR2(25),
author2 VARCHAR2(25),
publisher VARCHAR2(25),
year_of_publication VARCHAR2(4),
no_of_copies NUMBER(5));

INSERT INTO BooksInventory VALUES('101','Let Us C++','Yashavant Kanetkar','B.C. Desai','H.Schild',2000,3);
INSERT INTO BooksInventory VALUES('102','Mastersing VC++','P.J Allen','Yashavant Kanetkar','B.C. Desai',2005,4);
INSERT INTO BooksInventory VALUES('103','JAVA Complete Reference','H.Schild','Yashavant Kanetkar','B.C. Desai',2004,0);
INSERT INTO BooksInventory VALUES('104','J2EE Complete Reference','Yashavant Kanetkar','H.Schild','B.C. Desai',2000,1);
INSERT INTO BooksInventory VALUES('105','Relational DBMS','B.C. Desai','Yashavant Kanetkar','H.Schild',2000,6);

CREATE TABLE BooksRegistration(
registration_id VARCHAR2(4),
book_id VARCHAR2(4),
user_id VARCHAR2(4),
registrationdate DATE);

CREATE TABLE BookTransaction(
transaction_id varchar2(4), 
registration_id VARCHAR2(4),
issue_date DATE,
return_date DATE,
fine NUMBER(3));

SELECT * FROM booksregistration order by registration_id;
