package com.cg.plp.bean;

public class LibrarianBean 
{
	private String lUserId=null;
	private String lPassword=null;
	private String lName=null;
	private String lEmailId=null;
	private String lAddress=null;
	private String lGender=null;
	private String lPhonenum=null;
	
	public String getlUserId() {
		return lUserId;
	}
	public void setlUserId(String lUserId) {
		this.lUserId = lUserId;
	}
	public String getlPassword() {
		return lPassword;
	}
	public void setlPassword(String lPassword) {
		this.lPassword = lPassword;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getlEmailId() {
		return lEmailId;
	}
	public void setlEmailId(String lEmailId) {
		this.lEmailId = lEmailId;
	}
	public String getlAddress() {
		return lAddress;
	}
	public void setlAddress(String lAddress) {
		this.lAddress = lAddress;
	}
	public String getlGender() {
		return lGender;
	}
	public void setlGender(String lGender) {
		this.lGender = lGender;
	}
	public String getlPhonenum() {
		return lPhonenum;
	}
	public void setlPhonenum(String lPhonenum) {
		this.lPhonenum = lPhonenum;
	}
	
	
	
}
