package com.cg.plp.service;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.StudentBean;
import com.cg.plp.dao.*;
import com.cg.plp.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService
{
	ILibraryDao libraryDaoImpl=new LibraryDoaImpl();
	
	public boolean isUserValid(String id,String pwd) throws LibraryException
	{
		return libraryDaoImpl.isUserValid(id,pwd);
	}
	
	public int isBookAvailable(String bookid) throws LibraryException
	{
		return libraryDaoImpl.isBookAvailable(bookid);
	}
	
	public int addRequest(StudentBean studentBean,BookBean bookBean) throws LibraryException
	{
		return libraryDaoImpl.addRequest(studentBean,bookBean);
	}

	@Override
	public int registerUser(StudentBean studentBean)  throws LibraryException
	{
		int userId=libraryDaoImpl.registerUserDao(studentBean);
		return userId;
	}

	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException
	{
		return libraryDaoImpl.addBooks(bookBean);
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		return libraryDaoImpl.removeBook(bookId);
	}

}
