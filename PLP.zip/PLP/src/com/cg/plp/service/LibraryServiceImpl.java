package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookTransactionBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.dao.*;
import com.cg.plp.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService
{
	ILibraryDao libraryDaoImpl=new LibraryDoaImpl();
	
	
	
	
	public String getName(String id) throws LibraryException
	{
		return libraryDaoImpl.getName(id);
	}
	public int isUserValid(String id,String pwd) throws LibraryException
	{
		return libraryDaoImpl.isUserValid(id,pwd);
	}
	
	public int isBookAvailable(String bookid) throws LibraryException
	{
		return libraryDaoImpl.isBookAvailable(bookid);
	}
	
	public int addRequest(String userId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.addRequest(userId, bookId);
	}

	@Override
	public int registerUser(UserBean userBean)  throws LibraryException
	{
		int userId=libraryDaoImpl.registerUserDao(userBean);
		return userId;
	}

	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException
	{
		return libraryDaoImpl.addBooks(bookBean);
	}

	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		return libraryDaoImpl.removeBook(bookId);
	}

	@Override
	public int returnBook(String transactionId, String bookId) throws LibraryException
	{
		return libraryDaoImpl.returnBook(transactionId,bookId);
	}

	@Override
	public ArrayList displayRequests() throws LibraryException 
	{
		return libraryDaoImpl.displayRequests();
	}

	@Override
	public String grantBook(String registrationid, String bookId) throws LibraryException 
	{
		return libraryDaoImpl.grantBook(registrationid, bookId);
	}

}
