package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.spi.DirStateFactory.Result;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.util.LibraryDBConnection;


public class LibraryDoaImpl implements ILibraryDao
{
	
	public boolean isUserValid(String id,String pwd) throws LibraryException
	{
		boolean status=false;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT password FROM UserTable WHERE userid=?");
			preparedStatement.setString(1,id);
			resultSet=preparedStatement.executeQuery();
			//System.out.println("Entered uid:"+id);
			//System.out.println("Entered pwd:"+pwd);
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(pwd))
				{
					//System.out.println("entered1");
					status=false;
				}
				else
				{
					System.out.println("Incorrect password.Please enter a valid password");
					status=true;
				}
			}
			else
			{
				System.out.println("Incorrect userid.Please enter a valid userid");
				status=true;
			}
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
	
	
	public int isBookAvailable(String bookid) throws LibraryException
	{
		
		int status=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.BOOKAVAILABILITY);
			preparedStatement.setString(1,bookid);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int copies=resultSet.getInt("no_of_copies");
				if(copies>0)
				{
					status=1;
				}
				else
				{
					status=2;
				}
			}
			else
				status=3;
			return status;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
	}
	
	
	public int addRequest(StudentBean studentBean,BookBean bookBean) throws LibraryException
	{
		int registrationId=0;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.ADDUSER);
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,studentBean.getsUserId());
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("SELECT registration_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			registrationId=rs.getInt(1);
			
			System.out.println("User id is:"+registrationId);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing db connection");
			}
		}
		return registrationId;
	}


	@Override
	public int registerUserDao(StudentBean studentBean) throws LibraryException
	{
		int userId=0;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERTUSER);
			preparedStatement.setString(1,studentBean.getsPassword());
			preparedStatement.setString(2,studentBean.getsName());
			preparedStatement.setString(3,studentBean.getsEmailId());
			preparedStatement.setString(4,studentBean.getsAddress());
			preparedStatement.setString(5,studentBean.getsGender());
			preparedStatement.setString(6,studentBean.getsPhonenum());
			preparedStatement.setString(7,studentBean.getLibrarian());
			preparedStatement.executeUpdate();
			connection.commit();
			
			preparedStatement=connection.prepareStatement("SELECT user_id_seq.CURRVAL FROM DUAL");
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			userId=rs.getInt(1);
			
			System.out.println("User id is:"+userId);
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		
		return userId;
	}


	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException 
	{
		boolean status=false;
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERTBOOK);
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,bookBean.getBookName());
			preparedStatement.setString(3,bookBean.getAuthor1());
			preparedStatement.setString(4,bookBean.getAuthor2());
			preparedStatement.setString(5,bookBean.getPublisher());
			preparedStatement.setString(6,bookBean.getYearOfPublication());
			preparedStatement.setInt(7,bookBean.getNoOfCopies());
			preparedStatement.executeUpdate();
			connection.commit();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return status;
	}


	@Override
	public boolean removeBook(String bookId) throws LibraryException
	{
		boolean status=false;
		
		Connection connection = LibraryDBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.DELETEBOOK);
			preparedStatement.setString(1, bookId);
			preparedStatement.executeUpdate();
			connection.commit();
			status=true;
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration phase");
			}
		}
		return status;
	}

}
