package com.cg.plp.dao;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.StudentBean;
import com.cg.plp.exception.LibraryException;

public interface ILibraryDao 
{
	public abstract boolean isUserValid(String id,String pwd) throws LibraryException;
	public abstract int isBookAvailable(String bookid) throws LibraryException;
	public abstract int addRequest(StudentBean studentBean,BookBean bookBean) throws LibraryException;
	
	public abstract int registerUserDao(StudentBean studentBean) throws LibraryException;
	public abstract boolean addBooks(BookBean bookBean) throws LibraryException;
	public abstract boolean removeBook(String bookId) throws LibraryException;
}
