package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.UserDetails;
import com.cg.service.EBill;
import com.cg.service.IEBill;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		UserDetails user=new UserDetails();
		IEBill ebill=new EBill();
		
		int fixedCharge=100;
		String operation=request.getParameter("action");
		
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		if(operation.equals("isValid"))
		{
			if(username.equals("admin") && password.equals("admin"))
			{
				response.sendRedirect("BillDetails.html");
			}
			else
			{
				response.sendRedirect("User.html");
			}
		}
		
		if(operation.equals("calculate"))
		{
			boolean status;
			int consumerno=Integer.parseInt(request.getParameter("consumerno"));
			int lastMonth=Integer.parseInt(request.getParameter("lastmonth"));
			int currentMonth=Integer.parseInt(request.getParameter("currentmonth"));
			
			user.setConsumerno(consumerno);
			user.setLastmonth(lastMonth);
			user.setCurrentMonth(currentMonth);
			
			int unitsConsumed=currentMonth - lastMonth;
			float bill= ((unitsConsumed * 1.15f) + fixedCharge);
			
			user.setUnitsconsumed(unitsConsumed);
			user.setBill(bill);
			
			status=ebill.checkConsumerNo(consumerno);
			
			if(status==false)
			{
				response.sendRedirect("Failure.html");
			}
			else
			{
				
				ebill.addBillDetails(user);
				PrintWriter pw=response.getWriter();

				String name=ebill.getUserName(consumerno);
				pw.println("Bill is "+user.getBill());
				pw.println("Name is"+name);
			}
		}
	}

}
