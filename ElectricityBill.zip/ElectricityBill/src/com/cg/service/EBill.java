package com.cg.service;

import com.cg.bean.UserDetails;
import com.cg.dao.EBillDao;
import com.cg.dao.IEBillDao;

public class EBill implements IEBill
{
	IEBillDao ebill=new EBillDao();

	@Override
	public void addBillDetails(UserDetails userdetails)
	{
		//UserDetails ud;
		//ud=ebill.addBillDetails(userdetails);
		//return ud;
		ebill.addBillDetails(userdetails);
	}

	@Override
	public boolean checkConsumerNo(int consumerno) 
	{
		boolean status=ebill.checkConsumerNo(consumerno);
		return status;
	}

	@Override
	public String getUserName(int consumerno)
	{
		String name=ebill.getUserName(consumerno);
		return name;
	}

}
