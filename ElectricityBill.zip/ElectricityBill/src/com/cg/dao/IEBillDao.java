package com.cg.dao;

import com.cg.bean.UserDetails;

public interface IEBillDao 
{
	public abstract void addBillDetails(UserDetails userdetails);
	public abstract boolean checkConsumerNo(int consumerno);
	public abstract String getUserName(int consumerno);
}
