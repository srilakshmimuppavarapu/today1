package com.cg.dao;

public interface IQueryMapper
{
	public static final String adddetails="insert into billdetails values(seq_bill_num.nextval,?,?,?,?,SYSDATE)";
	public static final String getdetails="select * from consumers where consumer_num=?";
	public static final String getName="select consumer_name from consumers where consumer_num=?";
}
