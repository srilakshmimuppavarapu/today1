package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.bean.UserDetails;



public class EBillDao implements IEBillDao
{

	@Override
	public void addBillDetails(UserDetails userdetails)
	{
		try 
		{
			InitialContext ic = new InitialContext();
			//System.out.println("hai1111");
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			//System.out.println("hai111");
			Connection con=ds.getConnection();

			PreparedStatement ps=con.prepareStatement(IQueryMapper.adddetails);
			ps.setInt(1,userdetails.getConsumerno());
			ps.setFloat(2,userdetails.getCurrentMonth());
			ps.setFloat(3,userdetails.getUnitsconsumed());
			ps.setFloat(4,userdetails.getBill());
			//System.out.println("hai");
			ps.executeUpdate();
			
		} 
		catch (NamingException e)
		{		
			System.out.println(e.getMessage());
		} 
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}

	@Override
	public boolean checkConsumerNo(int consumerno)
	{
		UserDetails user=new UserDetails();
		boolean status=false;
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement(IQueryMapper.getdetails);
			ps.setInt(1, consumerno);
			ResultSet rs=ps.executeQuery();
			
			//rs.next();
			
			if(rs.next()==false)
			{
				System.out.println("You entered an incorrect consumer id");
			}
			else
			{
				int num=rs.getInt(1);
				String name=rs.getString(2);
				String address=rs.getString(3);
				//System.out.println("name is "+name);
				user.setName(name);
				status=true;
			}
			
		}
		catch (NamingException e)
		{		
			System.out.println(e.getMessage());
		} 
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return status;
	}

	@Override
	public String getUserName(int consumerno)
	{
		String name=null;
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			
			PreparedStatement ps=con.prepareStatement(IQueryMapper.getName);
			
			ps.setInt(1, consumerno);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			name=rs.getString(1);
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		} 
		catch (NamingException e) 
		{
			System.out.println(e.getMessage());
		}
		return name;
	}

}
