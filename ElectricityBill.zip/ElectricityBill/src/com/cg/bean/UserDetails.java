package com.cg.bean;

public class UserDetails
{
	private int consumerno;
	private int lastmonth;
	private int currentMonth;
	private int unitsconsumed;
	private float bill;
	private String name;

	
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public int getUnitsconsumed()
	{
		return unitsconsumed;
	}
	public void setUnitsconsumed(int unitsconsumed)
	{
		this.unitsconsumed = unitsconsumed;
	}
	
	public float getBill() 
	{
		return bill;
	}
	public void setBill(float bill)
	{
		this.bill = bill;
	}
	
	public int getConsumerno() 
	{
		return consumerno;
	}
	public void setConsumerno(int consumerno)
	{
		this.consumerno = consumerno;
	}
	
	public int getLastmonth() 
	{
		return lastmonth;
	}
	public void setLastmonth(int lastmonth)
	{
		this.lastmonth = lastmonth;
	}
	
	public int getCurrentMonth() 
	{
		return currentMonth;
	}
	public void setCurrentMonth(int currentMonth) 
	{
		this.currentMonth = currentMonth;
	}
	
}
